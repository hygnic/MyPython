Chapter 1
===

Setting Up
---

Python runs on all modern operating systems, but the setup process is slightly different on each operating system:

- [Linux](linux_setup.md)
- [OS X](osx_setup.md)
- [Windows](windows_setup.md)